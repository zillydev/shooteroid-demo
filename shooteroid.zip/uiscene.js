class Button extends Phaser.GameObjects.Image {
    constructor(scene, x, y, key, onclick) {
        super(scene, x, y, key);
        scene.add.existing(this);
        this.setInteractive();
        this.on('pointerup', onclick, scene);
    }
}

class UIScene extends Phaser.Scene {
    constructor() {
        super({ key: 'UIScene' });
    }

    preload() {
        this.load.image('larger', 'assets/larger.png');
        this.load.image('smaller', 'assets/smaller.png');
        this.load.image('health', 'assets/playerLife1_orange.png');
    }

    create() {
        var scoreText = this.add.bitmapText(16, 16, 'spaceFont', "Score: 0");
        var healthGroup = this.add.group();
        for (var i=0;i<3;i++) {
            var health = this.add.image(windowWidth - 125 + (i*50), 34, 'health');
            health.setName(i);
            healthGroup.add(health);
        }
        /* var btnFullscreen = new Button(this, windowWidth - 50, 50, 'larger', function() {
            game.events.emit('fullscreen');
        }); */
        if (isDeviceMobile) {
            this.input.addPointer();
            joyStick1 = this.plugins.get('rexvirtualjoystickplugin').add(this, {
                x: 200,
                y: windowHeight - 150,
                radius: 50,
                forceMin: 7
            });
            joyStick2 = this.plugins.get('rexvirtualjoystickplugin').add(this, {
                x: windowWidth - 200,
                y: windowHeight - 150,
                radius: 50
            });
            joyStick2.on('update', function() {
                game.events.emit('rotate', joyStick2.angle);
            }, this);
            game.events.on('resize', function(gameSize) {
                joyStick1.setPosition(200, gameSize.height - 150)//.setScale(scaleFactorX, scaleFactorY);
                joyStick2.setPosition(gameSize.width - 200, gameSize.height - 150)//.setScale(scaleFactorX, scaleFactorY);
                scoreText.setScale(scaleFactorX, scaleFactorY);
            }, this);
        }
        game.events.on('addScore', function(score) {
            scoreText.setText("Score: " + score);
        }, this);
        game.events.on('reduceHealth', function() {
            healthGroup.getFirstAlive().destroy();
        }, this);
        /* game.events.on('larger', function() {
            btnFullscreen.setTexture('larger');
        });
        game.events.on('smaller', function() {
            btnFullscreen.setTexture('smaller');
        }); */
        game.events.on('resize', function(gameSize, scaleFactorX, scaleFactorY) {
            //btnFullscreen.setPosition(gameSize.width - 35, 30).setScale(scaleFactorX, scaleFactorY);
            healthGroup.children.iterate(function(child) {
                child.setPosition(windowWidth - 125 + (child.name*50), 34);
            })
        }, this);
    }

    update() {
        if (isDeviceMobile) {
            if (joyStick1.force >= 7) {
                game.events.emit('move', joyStick1.angle);
            }
            if (joyStick2.force >= 60) {
                game.events.emit('shoot');
            }
        }
    }
}